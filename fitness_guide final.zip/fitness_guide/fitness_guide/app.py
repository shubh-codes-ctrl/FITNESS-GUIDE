from flask import Flask, request, jsonify, render_template, session, send_from_directory
import sqlite3
import bcrypt
import random
from datetime import date, datetime
import os

app = Flask(__name__)
app.secret_key = 'my_fitness_secret_key'

def init_db():
    with sqlite3.connect('fitness_guide.db') as conn:
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS habits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            habit TEXT NOT NULL,
            frequency TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS challenges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            date TEXT NOT NULL,
            challenge TEXT NOT NULL,
            completed BOOLEAN DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS workouts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            title TEXT NOT NULL,
            video_url TEXT NOT NULL,
            duration INTEGER NOT NULL,
            fitness_level TEXT NOT NULL
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS workout_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            workout_id INTEGER,
            completed_date TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (workout_id) REFERENCES workouts (id)
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS playlists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            workout_id INTEGER,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (workout_id) REFERENCES workouts (id)
        )''')
        conn.commit()

@app.route('/')
def login_page():
    return render_template('login.html')

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'), 'favicon.ico', mimetype='image/vnd.microsoft.icon')

@app.route('/<path:filename>')
def serve_static(filename):
    if filename.endswith('.html'):
        return render_template(filename)
    return send_from_directory(os.path.join(app.root_path, 'static'), filename)

@app.route('/challenges')
def challenges():
    return render_template('challenges.html')

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    if username and password:
        session['user_id'] = 1  # Fake login
        return jsonify({'message': 'Login successful', 'redirect': '/index.html'}), 200
    else:
        return jsonify({'error': 'Username and password required'}), 400

@app.route('/add_habit', methods=['POST'])
def add_habit():
    data = request.get_json()
    habit = data.get('habit')
    frequency = data.get('frequency')
    user_id = 1
    try:
        with sqlite3.connect('fitness_guide.db') as conn:
            c = conn.cursor()
            c.execute('INSERT INTO habits (user_id, habit, frequency) VALUES (?, ?, ?)', (user_id, habit, frequency))
            conn.commit()
        return jsonify({'message': 'Habit added'}), 200
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_challenge')
def get_challenge():
    challenges = [
        "Do 20 push-ups",
        "Walk 5,000 steps",
        "Hold a 1-minute plank",
        "Complete a 15-minute yoga session",
        "Run for 10 minutes",
        "Do 30 squats",
        "Complete a 20-minute stretching routine",
        "Perform 15 burpees"
    ]
    user_id = 1
    today = date.today().isoformat()
    try:
        with sqlite3.connect('fitness_guide.db') as conn:
            c = conn.cursor()
            c.execute('SELECT challenge FROM challenges WHERE user_id = ? AND date = ?', (user_id, today))
            result = c.fetchone()
            if not result:
                challenge = random.choice(challenges)
                c.execute('INSERT INTO challenges (user_id, date, challenge) VALUES (?, ?, ?)', (user_id, today, challenge))
                conn.commit()
            else:
                challenge = result[0]
            return jsonify({'challenge': challenge})
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/complete_challenge', methods=['POST'])
def complete_challenge():
    user_id = 1
    today = date.today().isoformat()
    try:
        with sqlite3.connect('fitness_guide.db') as conn:
            c = conn.cursor()
            c.execute('UPDATE challenges SET completed = 1 WHERE user_id = ? AND date = ?', (user_id, today))
            conn.commit()
        return jsonify({'message': 'Challenge completed!'})
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_workouts')
def get_workouts():
    category = request.args.get('category', 'Yoga')
    duration = request.args.get('duration', 'all')
    fitness_level = request.args.get('fitness_level', 'all')
    query = 'SELECT id, title, video_url, duration, fitness_level FROM workouts WHERE category = ?'
    params = [category]
    if duration != 'all':
        if duration == 'short':
            query += ' AND duration < 15'
        elif duration == 'medium':
            query += ' AND duration BETWEEN 15 AND 30'
        elif duration == 'long':
            query += ' AND duration > 30'
    if fitness_level != 'all':
        query += ' AND fitness_level = ?'
        params.append(fitness_level)
    try:
        with sqlite3.connect('fitness_guide.db') as conn:
            c = conn.cursor()
            c.execute(query, params)
            videos = [{'id': row[0], 'title': row[1], 'video_url': row[2], 'duration': row[3], 'fitness_level': row[4]} for row in c.fetchall()]
            return jsonify({'videos': videos})
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/complete_workout', methods=['POST'])
def complete_workout():
    data = request.get_json()
    workout_id = data.get('workout_id')
    user_id = 1
    today = date.today().isoformat()
    try:
        with sqlite3.connect('fitness_guide.db') as conn:
            c = conn.cursor()
            c.execute('INSERT INTO workout_progress (user_id, workout_id, completed_date) VALUES (?, ?, ?)', (user_id, workout_id, today))
            conn.commit()
        return jsonify({'message': 'Workout completed!'})
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_progress')
def get_progress():
    user_id = 1
    try:
        with sqlite3.connect('fitness_guide.db') as conn:
            c = conn.cursor()
            c.execute('SELECT COUNT(*) FROM workout_progress WHERE user_id = ?', (user_id,))
            completed = c.fetchone()[0]
            c.execute('SELECT COUNT(*) FROM workouts')
            total = c.fetchone()[0]
        return jsonify({'completed': completed, 'total': total})
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/save_playlist', methods=['POST'])
def save_playlist():
    data = request.get_json()
    workout_id = data.get('workout_id')
    user_id = 1
    try:
        with sqlite3.connect('fitness_guide.db') as conn:
            c = conn.cursor()
            c.execute('INSERT INTO playlists (user_id, workout_id) VALUES (?, ?)', (user_id, workout_id))
            conn.commit()
        return jsonify({'message': 'Added to playlist!'})
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    init_db()
    app.run(debug=True)