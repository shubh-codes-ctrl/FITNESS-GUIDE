import sqlite3
import bcrypt

username = "Shubhashree Bhosale"
password = "fitness"


hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

with sqlite3.connect("fitness_guide.db") as conn:
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
        conn.commit()
        print("✅ User added successfully!")
    except sqlite3.IntegrityError:
        print("⚠️ User already exists.")
