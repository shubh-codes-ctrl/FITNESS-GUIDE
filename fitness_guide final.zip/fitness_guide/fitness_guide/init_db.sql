CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS habits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    habit TEXT NOT NULL,
    frequency TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE TABLE IF NOT EXISTS challenges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    date TEXT NOT NULL,
    challenge TEXT NOT NULL,
    completed BOOLEAN DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE TABLE IF NOT EXISTS workouts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    title TEXT NOT NULL,
    video_url TEXT NOT NULL,
    duration INTEGER NOT NULL,
    fitness_level TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workout_progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    workout_id INTEGER,
    completed_date TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (workout_id) REFERENCES workouts (id)
);

CREATE TABLE IF NOT EXISTS playlists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    workout_id INTEGER,
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (workout_id) REFERENCES workouts (id)
);

-- Sample workout videos
INSERT INTO workouts (category, title, video_url, duration, fitness_level) VALUES
    ('Yoga', 'Beginner Yoga Flow', 'https://www.youtube.com/embed/v7AYKMP6rOE', 20, 'Beginner'),
    ('Yoga', 'Morning Yoga Routine', 'https://www.youtube.com/embed/4vTxkQA1I8w', 15, 'Beginner'),
    ('Strength Training', 'Full Body Strength Workout', 'https://www.youtube.com/embed/ykJmrZ5v0Oo', 30, 'Intermediate'),
    ('Strength Training', 'Dumbbell Strength Training', 'https://www.youtube.com/embed/8lP8zP0R4m8', 25, 'Intermediate'),
    ('Cardio', 'HIIT Cardio Workout', 'https://www.youtube.com/embed/5dbEHXwb6ok', 20, 'Advanced'),
    ('Cardio', '20-Minute Cardio Blast', 'https://www.youtube.com/embed/ml6N-6Vex80', 20, 'Intermediate'),
    ('Muscle Training', 'Muscle Building Routine', 'https://www.youtube.com/embed/2C-uNgXnYmg', 40, 'Advanced'),
    ('Muscle Training', 'Upper Body Muscle Workout', 'https://www.youtube.com/embed/1fbU_MkV7NE', 30, 'Intermediate'),
    ('Stretching', 'Full Body Stretch', 'https://www.youtube.com/embed/2gq3-e9oP4w', 10, 'Beginner'),
    ('Stretching', 'Post-Workout Stretch', 'https://www.youtube.com/embed/7z0bK-kw4q4', 12, 'Beginner');

-- Sample user (password: test123)
INSERT INTO users (username, password) VALUES ('testuser', '$2b$12$5z9tK0bL5z9tK0bL5z9tK.5z9tK0bL5z9tK0bL5z9tK0bL5z9tK.');